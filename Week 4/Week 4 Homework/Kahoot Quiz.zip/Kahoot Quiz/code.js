var x = 0;
setText("Q1Number", x);
setText("Q2Score", x);
setText("Q3Score", x);
setText("Q4Score", x);
setText("FinalScore", x);
setScreen("screen1");
onEvent("StartButton", "click", function() {
  setScreen("Q1Screen");
});
onEvent("VariablesButton", "click", function() {
  setProperty("VariablesButton", "background-color", "red");
  setProperty("CopyButton", "background-color", "red");
  setProperty("ControlButton", "background-color", "green");
  setProperty("ButtonsButton", "background-color", "red");
  setText("Q2Score", x);
  setTimeout(function() {
    setScreen("Q2Screen");
  }, 1500);
});
onEvent("CopyButton", "click", function( ) {
  setProperty("VariablesButton", "background-color", "red");
  setProperty("CopyButton", "background-color", "red");
  setProperty("ControlButton", "background-color", "green");
  setProperty("ButtonsButton", "background-color", "red");
  setText("Q2Score", x);
  setTimeout(function() {
    setScreen("Q2Screen");
  }, 1500);
});
onEvent("ControlButton", "click", function() {
  setProperty("ControlButton", "background-color", "green");
  setProperty("VariablesButton", "background-color", "red");
  setProperty("CopyButton", "background-color", "red");
  setProperty("ButtonsButton", "background-color", "red");
  x = x + 1;
  setText("Q1Number", x);
  setText("Q2Score", x);
  setTimeout(function() {
    setScreen("Q2Screen");
  }, 1500);
});
onEvent("ButtonsButton", "click", function( ) {
  setProperty("VariablesButton", "background-color", "red");
  setProperty("CopyButton", "background-color", "red");
  setProperty("ControlButton", "background-color", "green");
  setProperty("ButtonsButton", "background-color", "red");
  setText("Q2Score", x);
  setTimeout(function() {
    setScreen("Q2Screen");
  }, 1500);
});
onEvent("Q2Blue", "click", function() {
  setProperty("Q2Blue", "background-color", "red");
  setProperty("Q2Green", "background-color", "red");
  setProperty("Q2Red", "background-color", "green");
  setProperty("Q2Yellow", "background-color", "red");
  setText("Q3Score", x);
  setTimeout(function() {
    setScreen("Q3Screen");
  }, 1500);
});
onEvent("Q2Green", "click", function( ) {
  setProperty("Q2Blue", "background-color", "red");
  setProperty("Q2Green", "background-color", "red");
  setProperty("Q2Red", "background-color", "green");
  setProperty("Q2Yellow", "background-color", "red");
  setText("Q3Score", x);
  setTimeout(function() {
    setScreen("Q3Screen");
  }, 1500);
});
onEvent("Q2Red", "click", function() {
  setProperty("Q2Green", "background-color", "red");
  setProperty("Q2Blue", "background-color", "red");
  setProperty("Q2Red", "background-color", "green");
  setProperty("Q2Yellow", "background-color", "red");
  x = x + 1;
  setText("Q2Score", x);
  setText("Q3Score", x);
  setTimeout(function() {
    setScreen("Q3Screen");
  }, 1500);
});
onEvent("Q2Yellow", "click", function( ) {
  setProperty("Q2Blue", "background-color", "red");
  setProperty("Q2Green", "background-color", "red");
  setProperty("Q2Red", "background-color", "green");
  setProperty("Q2Yellow", "background-color", "red");
  setText("Q3Score", x);
  setTimeout(function() {
    setScreen("Q3Screen");
  }, 1500);
});
onEvent("Q3Blue", "click", function() {
  setProperty("Q3Blue", "background-color", "green");
  setProperty("Q3Red", "background-color", "red");
  x = x + 1;
  setText("Q3Score", x);
  setText("Q4Score", x);
  setTimeout(function() {
    setScreen("Q4Screen");
  }, 1500);
});
onEvent("Q3Red", "click", function( ) {
  setProperty("Q3Blue", "background-color", "green");
  setProperty("Q3Red", "background-color", "red");
  setText("Q4Score", x);
  setTimeout(function() {
    setScreen("Q4Screen");
  }, 1500);
});
onEvent("Q4Blue", "click", function() {
  setProperty("Q4Blue", "background-color", "red");
  setProperty("Q4Red", "background-color", "green");
  setText("FinalScore", x);
  setTimeout(function() {
    setScreen("FinalScreen");
  }, 1500);
});
onEvent("Q4Red", "click", function( ) {
  setProperty("Q4Blue", "background-color", "red");
  setProperty("Q4Red", "background-color", "green");
  x = x + 1;
  setText("Q4Score", x);
  setText("FinalScore", x);
  setTimeout(function() {
    setScreen("FinalScreen");
  }, 1500);
});
